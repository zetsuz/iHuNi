# TrueDiceZBot
An auto bot for truedice.io
